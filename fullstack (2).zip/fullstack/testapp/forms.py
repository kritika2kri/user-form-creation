from django import forms
from phonenumber_field.formfields import PhoneNumberField


class Detail(forms.Form):
    Name = forms.CharField(max_length=64)
    contact = PhoneNumberField()
    Email = forms.EmailField()
    date = forms.DateField()

