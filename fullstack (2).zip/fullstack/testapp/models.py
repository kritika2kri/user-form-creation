from django.db import models
from django.utils import timezone

from phonenumber_field.modelfields import PhoneNumberField
import phonenumbers
class comment(models.Model):
    Name = models.CharField(max_length=64)
    contact = PhoneNumberField(null=False,blank=False,unique=True)
    Email = models.EmailField()
    date = models.DateField()
