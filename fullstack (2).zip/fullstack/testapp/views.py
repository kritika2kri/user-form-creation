from django.shortcuts import render,redirect
from .forms import Detail
from .models import comment

def ind(request):

    return render (request, 'sign.html')



def sign(request):
    if request.method == 'POST':
        form = Detail(request.POST)

        if form.is_valid():
            new_form = comment(Name=request.POST['Name'],date= request.POST['date'],
            contact=request.POST['contact'], Email=request.POST['Email'])
            new_form.save()
            return redirect('ind')



    else:
        form = Detail()

    context = {'form' : form}
    return render(request, 'form.html', context)
